// ==========================================================================
// TỔNG QUAN FILE: Controllers/SearchController.cs
// - File này làm gì: Điều khiển chức năng Trang kết quả tìm kiếm & Lọc phòng
//   (Search/Results).
// - Nằm ở đâu trong dự án: Thư mục Controllers/SearchController.cs.
// - Cách chạy / gọi đến file này: Khi truy cập đường dẫn "/Search/Results"
//   hoặc bấm nút "Tìm ngay" từ form tìm kiếm ở Trang chủ.
// ==========================================================================

// Khai báo thư viện System.Web.Mvc để kế thừa lớp Controller
using System.Web.Mvc;
// Gọi namespace chứa các class Model và kho dữ liệu giả
using ChamBooking.Models;

namespace ChamBooking.Controllers
{
    // Khai báo class SearchController chuyên phụ trách chức năng Tìm kiếm khách sạn
    public class SearchController : Controller
    {
        // ------------------------------------------------------------------
        // ACTION: Results(string city)
        // - Trả về View nào: Views/Search/Results.cshtml (Trang kết quả tìm kiếm).
        // - Truyền dữ liệu giả gì: Truyền danh sách các Card khách sạn từ Mock Data
        //   và tên thành phố đang lọc qua ViewBag.SelectedCity.
        // ------------------------------------------------------------------
        public ActionResult Results(string city = "")
        {
            // Lấy danh sách khách sạn từ kho dữ liệu giả ChamMockData
            var hotels = ChamMockData.GetHotels();
            // Lưu tên điểm đến người dùng vừa chọn vào ViewBag để hiển thị trên tiêu đề
            ViewBag.SelectedCity = string.IsNullOrEmpty(city) ? "Tất cả điểm đến" : city;
            // Trả về giao diện Views/Search/Results.cshtml kèm danh sách khách sạn
            return View(hotels);
        }
    }
}
