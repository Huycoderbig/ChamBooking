// ==========================================================================
// TỔNG QUAN FILE: Controllers/AdminController.cs
// - File này làm gì: Điều khiển chức năng Giao diện Quản trị hệ thống (Admin UI)
//   gồm Quản lý Khách sạn, Phòng, Booking, Đánh giá (Reviews) và Lịch sử Giao dịch (Payments).
// - Nằm ở đâu trong dự án: Thư mục Controllers/AdminController.cs.
// - Cách chạy / gọi đến file này: Khi truy cập đường dẫn "/Admin/Dashboard"
//   hoặc bấm nút "Quản trị (Admin)" trên thanh Navbar.
// ==========================================================================

// Khai báo thư viện System.Web.Mvc để kế thừa lớp Controller
using System.Web.Mvc;
// Gọi namespace chứa các class Model và kho dữ liệu giả
using ChamBooking.Models;

namespace ChamBooking.Controllers
{
    // Khai báo class AdminController chuyên phụ trách khu vực Quản trị (Admin UI)
    public class AdminController : Controller
    {
        // ------------------------------------------------------------------
        // ACTION: Dashboard()
        // - Trả về View nào: Views/Admin/Dashboard.cshtml (Giao diện Quản trị Admin).
        // - Truyền dữ liệu giả gì:
        //   + Danh sách Khách sạn làm Model chính.
        //   + Danh sách Loại phòng qua ViewBag.RoomTypes.
        //   + Danh sách Booking & Lịch sử giao dịch (Payments) qua ViewBag.Transactions.
        //   + Danh sách Đánh giá khách hàng (Reviews) qua ViewBag.Reviews.
        // ------------------------------------------------------------------
        public ActionResult Dashboard()
        {
            // Truyền danh sách đơn đặt phòng và lịch sử thanh toán vào ViewBag.Transactions
            ViewBag.Transactions = ChamMockData.GetAdminTransactions();
            // Truyền danh sách đánh giá khách hàng vào ViewBag.Reviews
            ViewBag.Reviews = ChamMockData.GetReviews();
            // Truyền danh sách hạng phòng vào ViewBag.RoomTypes
            ViewBag.RoomTypes = ChamMockData.GetRoomTypes();
            // Lấy danh sách khách sạn truyền làm Model chính của trang Admin
            var hotels = ChamMockData.GetHotels();
            // Trả về giao diện Views/Admin/Dashboard.cshtml
            return View(hotels);
        }
    }
}
