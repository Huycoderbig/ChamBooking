// ==========================================================================
// TỔNG QUAN FILE: Controllers/HomeController.cs
// - File này làm gì: Điều khiển chức năng Trang chủ (Home/Index) của website.
// - Nằm ở đâu trong dự án: Thư mục Controllers/HomeController.cs.
// - Cách chạy / gọi đến file này: Khi truy cập đường dẫn gốc "/" hoặc "/Home/Index".
// ==========================================================================

// Khai báo thư viện System.Web.Mvc để sử dụng lớp Controller và ActionResult
using System.Web.Mvc;
// Gọi namespace chứa kho dữ liệu giả ChamMockData
using ChamBooking.Models;

namespace ChamBooking.Controllers
{
    // Khai báo class HomeController kế thừa từ lớp Controller của ASP.NET MVC 5
    public class HomeController : Controller
    {
        // ------------------------------------------------------------------
        // ACTION: Index()
        // - Trả về View nào: Views/Home/Index.cshtml (Giao diện Trang chủ).
        // - Truyền dữ liệu giả gì:
        //   + Danh sách Khách sạn giá tốt qua Model chính của View.
        //   + Danh sách Điểm đến nổi bật qua ViewBag.Destinations.
        //   + Danh sách Đánh giá nổi bật (Reviews) qua ViewBag.Reviews.
        // ------------------------------------------------------------------
        public ActionResult Index()
        {
            // Truyền danh sách 4 Điểm đến nổi bật vào túi chứa tạm ViewBag.Destinations
            ViewBag.Destinations = ChamMockData.GetDestinations();
            // Truyền danh sách 3 Đánh giá khách hàng nổi bật vào ViewBag.Reviews
            ViewBag.Reviews = ChamMockData.GetReviews();
            // Lấy danh sách Khách sạn giả lập làm dữ liệu Model chính của Trang chủ
            var hotels = ChamMockData.GetHotels();
            // Trả về giao diện Views/Home/Index.cshtml
            return View(hotels);
        }
    }
}
