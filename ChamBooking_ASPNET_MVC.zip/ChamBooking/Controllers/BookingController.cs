// ==========================================================================
// TỔNG QUAN FILE: Controllers/BookingController.cs
// - File này làm gì: Điều khiển chức năng Luồng đặt phòng & Thanh toán
//   (Booking/Checkout & Payments).
// - Nằm ở đâu trong dự án: Thư mục Controllers/BookingController.cs.
// - Cách chạy / gọi đến file này: Khi truy cập đường dẫn "/Booking/Checkout"
//   hoặc bấm nút "Đặt ngay" từ bảng loại phòng ở trang Chi tiết khách sạn.
// ==========================================================================

// Khai báo thư viện System.Linq để tìm kiếm khách sạn và loại phòng theo mã
using System.Linq;
// Khai báo thư viện System.Web.Mvc để kế thừa lớp Controller
using System.Web.Mvc;
// Gọi namespace chứa các class Model và kho dữ liệu giả
using ChamBooking.Models;

namespace ChamBooking.Controllers
{
    // Khai báo class BookingController chuyên phụ trách Đặt phòng & Thanh toán (Payments)
    public class BookingController : Controller
    {
        // ------------------------------------------------------------------
        // ACTION: Checkout(int hotelId = 101, string roomCode = "RM-01", int qty = 1)
        // - Trả về View nào: Views/Booking/Checkout.cshtml (Giao diện Đặt phòng & Thanh toán).
        // - Truyền dữ liệu giả gì:
        //   + Danh sách Phương thức thanh toán (Visa, MoMo, Tiền mặt) làm Model chính.
        //   + Thông tin Khách sạn, Loại phòng, Số lượng, Tiền phòng, Thuế (10%) và
        //     Tổng tiền thanh toán qua ViewBag để hiển thị ở cột Tóm tắt đơn hàng.
        // ------------------------------------------------------------------
        public ActionResult Checkout(int hotelId = 101, string roomCode = "RM-01", int qty = 1)
        {
            // Tìm thông tin khách sạn mà khách đang chọn đặt
            var hotel = ChamMockData.GetHotels().FirstOrDefault(h => h.Id == hotelId) ?? ChamMockData.GetHotels()[0];
            // Tìm thông tin hạng phòng mà khách đã chọn
            var room = ChamMockData.GetRoomTypes().FirstOrDefault(r => r.RoomCode == roomCode) ?? ChamMockData.GetRoomTypes()[0];

            // Tính tiền phòng tạm tính cho kỳ nghỉ 2 đêm (Đơn giá 1 đêm * Số lượng phòng * 2 đêm)
            decimal roomSubTotal = room.Price * qty * 2;
            // Tính thuế VAT và phí dịch vụ (10% của tiền phòng)
            decimal taxAndFee = roomSubTotal * 0.10m;
            // Tính tổng số tiền cuối cùng khách cần thanh toán
            decimal grandTotal = roomSubTotal + taxAndFee;

            // Đưa các biến thông tin tóm tắt đơn hàng vào ViewBag để cột phải của View hiển thị
            ViewBag.SelectedHotel = hotel;
            ViewBag.SelectedRoom = room;
            ViewBag.RoomQuantity = qty;
            ViewBag.RoomSubTotal = roomSubTotal;
            ViewBag.TaxAndFee = taxAndFee;
            ViewBag.GrandTotal = grandTotal;

            // Lấy danh sách các Phương thức thanh toán (MoMo, Visa, Tiền mặt) truyền làm Model chính
            var paymentMethods = ChamMockData.GetPaymentMethods();
            // Trả về giao diện Views/Booking/Checkout.cshtml
            return View(paymentMethods);
        }
    }
}
