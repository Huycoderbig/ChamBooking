// ==========================================================================
// TỔNG QUAN FILE: Controllers/HotelController.cs
// - File này làm gì: Điều khiển chức năng Trang chi tiết khách sạn, Bảng loại phòng
//   và Khu vực Đánh giá khách hàng (Hotel/Details).
// - Nằm ở đâu trong dự án: Thư mục Controllers/HotelController.cs.
// - Cách chạy / gọi đến file này: Khi truy cập đường dẫn "/Hotel/Details?id=101"
//   hoặc bấm nút "Xem phòng" trên các thẻ Card khách sạn.
// ==========================================================================

// Khai báo thư viện System.Linq để dùng hàm tìm kiếm FirstOrDefault()
using System.Linq;
// Khai báo thư viện System.Web.Mvc để kế thừa lớp Controller
using System.Web.Mvc;
// Gọi namespace chứa các class Model và kho dữ liệu giả
using ChamBooking.Models;

namespace ChamBooking.Controllers
{
    // Khai báo class HotelController chuyên phụ trách thông tin chi tiết khách sạn & Reviews
    public class HotelController : Controller
    {
        // ------------------------------------------------------------------
        // ACTION: Details(int id = 101)
        // - Trả về View nào: Views/Hotel/Details.cshtml (Trang chi tiết khách sạn).
        // - Truyền dữ liệu giả gì:
        //   + Đối tượng 1 Khách sạn cụ thể (HotelModel) làm Model chính.
        //   + Danh sách các Loại phòng (Room Types) qua ViewBag.RoomTypes.
        //   + Danh sách Bình luận Đánh giá (Reviews) qua ViewBag.Reviews.
        // ------------------------------------------------------------------
        public ActionResult Details(int id = 101)
        {
            // Tìm khách sạn theo mã id truyền vào, nếu không có thì mặc định lấy khách sạn đầu tiên (101)
            var hotel = ChamMockData.GetHotels().FirstOrDefault(h => h.Id == id) ?? ChamMockData.GetHotels()[0];
            // Truyền danh sách các Loại phòng (Room Types) xuống View thông qua ViewBag.RoomTypes
            ViewBag.RoomTypes = ChamMockData.GetRoomTypes();
            // Truyền danh sách Đánh giá (Reviews) của khách hàng cũ xuống View qua ViewBag.Reviews
            ViewBag.Reviews = ChamMockData.GetReviews();
            // Trả về giao diện Views/Hotel/Details.cshtml kèm đối tượng khách sạn
            return View(hotel);
        }
    }
}
