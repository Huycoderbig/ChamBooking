// ==========================================================================
// TỔNG QUAN FILE: Scripts/main.js
// - File này làm gì: Sử dụng thư viện jQuery để xử lý các hiệu ứng tương tác
//   trên giao diện (DOM) như: chuyển tab tìm kiếm, kéo thanh trượt giá,
//   đổi ảnh lớn trong Gallery, chọn phương thức thanh toán và chuyển tab Admin.
// - Nằm ở đâu trong dự án: Thư mục Scripts/main.js (chuẩn ASP.NET MVC 5).
// - Cách chạy / gọi đến file này: Được nhúng ở cuối file Views/Shared/_Layout.cshtml
//   ngay sau thư viện jQuery và Bootstrap 5.
// ==========================================================================

// Hàm $(document).ready() đợi toàn bộ thẻ HTML trên trang tải xong xuôi mới bắt đầu gắn sự kiện
$(document).ready(function () {

    // 1. Xử lý chuyển đổi Tab "Khách sạn" | "Tour" trên Hero Banner (Trang chủ Index.cshtml)
    $('.js-search-tab').on('click', function () {
        // Xóa class 'active' (nền xanh đậm) khỏi tất cả các nút tab
        $('.js-search-tab').removeClass('active');
        // Thêm class 'active' vào đúng nút mà người dùng vừa bấm chuột ($(this))
        $(this).addClass('active');

        // Đọc giá trị thuộc tính data-type ("hotel" hoặc "tour") của nút vừa bấm
        var tabType = $(this).data('type');
        // Nếu người dùng bấm sang tab "tour" thì đổi dòng chữ gợi ý sang tìm kiếm Tour
        if (tabType === 'tour') {
            $('#lbl-destination').text('ĐIỂM ĐẾN HOẶC TÊN TOUR TRẢI NGHIỆM');
            $('#inp-destination').attr('placeholder', 'VD: Tour săn mây Cầu Đất, Cáp treo Hòn Thơm...');
        } else {
            // Ngược lại nếu chọn tab "hotel" thì hiển thị gợi ý tìm kiếm Khách sạn
            $('#lbl-destination').text('ĐIỂM ĐẾN HOẶC TÊN KHÁCH SẠN');
            $('#inp-destination').attr('placeholder', 'Bạn muốn chạm đến đâu? (Đà Lạt, Phú Quốc, Hội An...)');
        }
    });

    // 2. Xử lý thanh trượt Khoảng giá (Slider) ở Sidebar trái trang Tìm kiếm (Search.cshtml)
    $('#priceRangeSlider').on('input change', function () {
        // Lấy số tiền hiện tại trên thanh trượt và chuyển sang kiểu số nguyên
        var maxPrice = parseInt($(this).val(), 10);
        // Định dạng số thành tiền Việt Nam (VD: 2.500.000 ₫) và cập nhật lên nhãn hiển thị
        $('#priceRangeLabel').text(maxPrice.toLocaleString('vi-VN') + ' ₫');

        // Duyệt qua từng thẻ khách sạn (.js-hotel-item) bên cột phải để ẩn/hiện tức thì theo giá
        $('.js-hotel-item').each(function () {
            // Lấy giá tiền của khách sạn được gắn trong thuộc tính data-price
            var hotelPrice = parseInt($(this).data('price'), 10);
            // Nếu giá khách sạn nhỏ hơn hoặc bằng mức thanh trượt thì hiện ra, ngược lại thì ẩn đi
            if (hotelPrice <= maxPrice) {
                $(this).stop(true, true).fadeIn(200);
            } else {
                $(this).stop(true, true).fadeOut(200);
            }
        });
    });

    // 3. Xử lý bấm vào ảnh phụ trong Gallery để đổi ảnh chính (Trang Chi tiết Details.cshtml)
    $('.js-gallery-thumb').on('click', function () {
        // Lấy đường dẫn ảnh (thuộc tính src) của tấm ảnh nhỏ vừa được bấm
        var newSrc = $(this).attr('src');
        // Làm mờ nhẹ ảnh lớn rồi thay bằng đường dẫn ảnh mới cho mượt mà
        $('#mainGalleryImage').fadeOut(150, function () {
            $(this).attr('src', newSrc).fadeIn(200);
        });
    });

    // 4. Xử lý Form Viết đánh giá mới (Reviews) ở cuối trang Chi tiết (Details.cshtml)
    $('#formNewReview').on('submit', function (e) {
        // Chặn hành vi tải lại trang mặc định của form HTML vì chưa kết nối Database thật
        e.preventDefault();
        // Lấy họ tên và nội dung nhận xét mà người dùng vừa gõ vào ô input
        var reviewerName = $('#revCustomerName').val();
        var reviewerComment = $('#revCommentText').val();
        var reviewerStars = $('#revStarSelect').val();

        // Tạo một thẻ bình luận HTML mới để chèn ngay lên đầu danh sách đánh giá
        var newReviewHtml =
            '<div class="col-md-6 mb-3">' +
                '<div class="review-card border-primary">' +
                    '<div class="d-flex justify-content-between align-items-center mb-2">' +
                        '<div class="d-flex align-items-center gap-2">' +
                            '<div class="review-avatar">MỚI</div>' +
                            '<div>' +
                                '<h6 class="fw-bold mb-0">' + reviewerName + '</h6>' +
                                '<small class="text-success">Vừa gửi đánh giá xong</small>' +
                            '</div>' +
                        '</div>' +
                        '<span class="rating-pill">' + reviewerStars + '.0 ★</span>' +
                    '</div>' +
                    '<p class="mb-0 text-secondary small">"' + reviewerComment + '"</p>' +
                '</div>' +
            '</div>';

        // Chèn thẻ bình luận mới vào đầu danh sách có id="reviewsContainer"
        $('#reviewsContainer').prepend(newReviewHtml);
        // Xóa trắng nội dung trong form và hiện thông báo gửi thành công
        this.reset();
        $('#reviewSuccessAlert').removeClass('d-none').hide().fadeIn(250);
    });

    // 5. Xử lý chọn Phương thức thanh toán (Visa, MoMo, Tiền mặt) ở trang Đặt phòng (Checkout.cshtml)
    $('.js-payment-option').on('click', function () {
        // Bỏ viền xanh (.active) ở tất cả các ô phương thức thanh toán
        $('.js-payment-option').removeClass('active');
        // Thêm viền xanh vào ô người dùng vừa bấm chọn
        $(this).addClass('active');
        // Tự động đánh dấu tích vào nút tròn radio bên trong ô đó
        $(this).find('input[type="radio"]').prop('checked', true);

        // Đọc dòng mô tả trạng thái giả lập trong thuộc tính data-status của ô vừa chọn
        var statusMsg = $(this).data('status');
        // Cập nhật dòng chữ hiển thị trạng thái thanh toán giả lập trên màn hình
        $('#simulatedPaymentStatus').html('<i class="bi bi-shield-check me-2"></i>' + statusMsg);
    });

    // 6. Xử lý nút "Xác nhận đặt phòng" chuyển sang màn hình Thành công / Biên lai (Checkout.cshtml)
    $('#formCheckoutBooking').on('submit', function (e) {
        // Ngăn trình duyệt gửi dữ liệu đi thật vì đang dùng Mock Data chưa lưu CSDL
        e.preventDefault();
        // Lấy họ tên và số điện thoại khách vừa nhập để in lên tờ Biên lai điện tử
        var fullName = $('#chkCustomerName').val() || 'Nguyễn Minh Khuê';
        var phone = $('#chkCustomerPhone').val() || '0908 412 889';
        var chosenMethod = $('.js-payment-option.active .js-method-name').text();

        // Điền tên khách, số điện thoại và phương thức thanh toán vào khung Biên lai
        $('#receiptCustomerName').text(fullName + ' (' + phone + ')');
        $('#receiptMethodName').text(chosenMethod);

        // Ẩn vùng nhập thông tin đặt phòng và hiện vùng Biên lai Thành công lên
        $('#checkoutFormArea').fadeOut(200, function () {
            $('#checkoutSuccessReceipt').removeClass('d-none').hide().fadeIn(350);
            // Cuộn màn hình lên đầu trang để nhìn thấy biên lai rõ ràng
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    });

    // 7. Xử lý chuyển đổi các bảng quản lý trong Sidebar trang Quản trị (Admin.cshtml)
    $('.js-admin-tab').on('click', function () {
        // Bỏ màu cam (.active) ở tất cả các nút trên Sidebar Admin
        $('.js-admin-tab').removeClass('active');
        // Tô màu cam cho nút mục quản lý vừa được bấm
        $(this).addClass('active');

        // Lấy id của bảng dữ liệu cần mở (lưu trong thuộc tính data-target)
        var targetPane = $(this).data('target');
        // Ẩn tất cả các bảng quản lý đi, sau đó chỉ hiện bảng được chọn
        $('.js-admin-pane').addClass('d-none');
        $('#' + targetPane).removeClass('d-none').hide().fadeIn(200);
    });

});
