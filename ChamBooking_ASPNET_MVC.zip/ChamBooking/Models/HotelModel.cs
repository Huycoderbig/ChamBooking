// ==========================================================================
// TỔNG QUAN FILE: Models/HotelModel.cs
// - File này làm gì: Định nghĩa class khuôn mẫu dữ liệu cho Khách sạn (dùng ở
//   Trang chủ, Trang Tìm kiếm, Trang Chi tiết khách sạn và Trang Quản trị Admin).
// - Nằm ở đâu trong dự án: Thư mục Models/HotelModel.cs.
// - Cách chạy / gọi đến file này: Được khởi tạo dữ liệu giả trong ChamMockData.cs
//   và truyền qua các Controller xuống View (.cshtml).
// ==========================================================================

// Khai báo thư viện danh sách List<T>
using System.Collections.Generic;

namespace ChamBooking.Models
{
    // Class lưu thông tin chi tiết của một Khách sạn / Khu nghỉ dưỡng
    public class HotelModel
    {
        // Mã định danh duy nhất của khách sạn (VD: 101, 102)
        public int Id { get; set; }
        // Tên đầy đủ của khách sạn
        public string Name { get; set; }
        // Thành phố nơi khách sạn tọa lạc (dùng để lọc theo điểm đến)
        public string City { get; set; }
        // Địa chỉ chi tiết số nhà, tên đường
        public string Address { get; set; }
        // Hạng sao tiêu chuẩn (từ 3 đến 5 sao)
        public int Stars { get; set; }
        // Điểm đánh giá trung bình từ khách hàng (thang điểm 10, VD: 9.4)
        public double RatingScore { get; set; }
        // Xếp loại bằng chữ tương ứng với điểm số (VD: "Tuyệt hảo", "Tuyệt vời")
        public string RatingLabel { get; set; }
        // Tổng số lượt khách hàng đã để lại đánh giá
        public int ReviewCount { get; set; }
        // Giá gốc khi chưa giảm (dùng để gạch ngang so sánh)
        public decimal OldPrice { get; set; }
        // Giá phòng thực tế mỗi đêm (đơn vị: VNĐ)
        public decimal PricePerNight { get; set; }
        // Nhãn ưu đãi nổi bật gắn trên góc ảnh (VD: "Ưu đãi lữ khách -31%")
        public string PromoBadge { get; set; }
        // Đường dẫn bức ảnh bìa chính của khách sạn
        public string MainImage { get; set; }
        // Danh sách các bức ảnh góc khác nhau của khách sạn (dùng cho Gallery trang Chi tiết)
        public List<string> GalleryImages { get; set; }
        // Danh sách các tiện nghi nổi bật (Hồ bơi, Bữa sáng, Wi-Fi...)
        public List<string> Amenities { get; set; }
        // Đoạn văn mô tả chi tiết không gian và trải nghiệm tại khách sạn
        public string Description { get; set; }
    }
}
