// ==========================================================================
// TỔNG QUAN FILE: Models/PaymentMethodModel.cs
// - File này làm gì: Định nghĩa class khuôn mẫu dữ liệu cho Phương thức thanh toán
//   (Payments: Ví MoMo, Thẻ Visa, Tiền mặt) ở luồng Đặt phòng.
// - Nằm ở đâu trong dự án: Thư mục Models/PaymentMethodModel.cs.
// - Cách chạy / gọi đến file này: Được truyền từ BookingController xuống giao diện
//   Views/Booking/Checkout.cshtml.
// ==========================================================================

namespace ChamBooking.Models
{
    // Class lưu thông tin một Phương thức thanh toán (Payment Method)
    public class PaymentMethodModel
    {
        // Mã phương thức (VD: "MOMO", "VISA", "CASH")
        public string Code { get; set; }
        // Tên phương thức thanh toán hiển thị cho khách chọn
        public string Title { get; set; }
        // Dòng giải thích ngắn gọn bên dưới tên phương thức
        public string Subtitle { get; set; }
        // Nhãn khuyên dùng hoặc ghi chú nhỏ bên góc phải
        public string Badge { get; set; }
        // Tên class icon của bộ Bootstrap Icons
        public string IconClass { get; set; }
        // Thông báo trạng thái thanh toán giả lập khi khách chọn phương thức này
        public string SimulatedStatus { get; set; }
    }
}
