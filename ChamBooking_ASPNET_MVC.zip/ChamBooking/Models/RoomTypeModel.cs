// ==========================================================================
// TỔNG QUAN FILE: Models/RoomTypeModel.cs
// - File này làm gì: Định nghĩa class khuôn mẫu dữ liệu cho từng Loại phòng
//   (Room Types) trong khách sạn.
// - Nằm ở đâu trong dự án: Thư mục Models/RoomTypeModel.cs.
// - Cách chạy / gọi đến file này: Dùng trong HotelController (Trang chi tiết),
//   BookingController (Trang đặt phòng) và AdminController (Quản lý phòng).
// ==========================================================================

// Khai báo thư viện danh sách List<T>
using System.Collections.Generic;

namespace ChamBooking.Models
{
    // Class lưu thông tin một Loại phòng (Room Type)
    public class RoomTypeModel
    {
        // Mã loại phòng (VD: "RM-01")
        public string RoomCode { get; set; }
        // Tên gọi của hạng phòng (VD: "Deluxe Pine View Balcony")
        public string RoomName { get; set; }
        // Diện tích phòng (VD: "36 m²")
        public string AreaSize { get; set; }
        // Loại giường ngủ trang bị trong phòng
        public string BedInfo { get; set; }
        // Sức chứa tối đa (số người lớn và trẻ em)
        public string Capacity { get; set; }
        // Giá tiền thuê 1 đêm của loại phòng này
        public decimal Price { get; set; }
        // Đường dẫn ảnh chụp thực tế của phòng
        public string RoomImage { get; set; }
        // Danh sách các quyền lợi đi kèm (Ăn sáng miễn phí, hủy miễn phí...)
        public List<string> Benefits { get; set; }
    }
}
