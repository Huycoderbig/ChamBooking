// ==========================================================================
// TỔNG QUAN FILE: Models/DestinationModel.cs
// - File này làm gì: Định nghĩa class khuôn mẫu dữ liệu cho Điểm đến nổi bật
//   (hiển thị ở Trang chủ).
// - Nằm ở đâu trong dự án: Thư mục Models/DestinationModel.cs.
// - Cách chạy / gọi đến file này: Được gọi trong ChamMockData.cs và truyền
//   qua HomeController xuống Views/Home/Index.cshtml.
// ==========================================================================

namespace ChamBooking.Models
{
    // Class lưu thông tin của một Điểm đến nổi bật (Đà Lạt, Phú Quốc, Hội An, Sa Pa)
    public class DestinationModel
    {
        // Tên thành phố hoặc địa danh du lịch
        public string Name { get; set; }
        // Khẩu hiệu ngắn mô tả không khí đặc trưng của điểm đến
        public string Vibe { get; set; }
        // Số lượng khách sạn / chỗ nghỉ hiện có tại điểm đến đó
        public int HotelCount { get; set; }
        // Đường dẫn ảnh đại diện của điểm đến
        public string ImageUrl { get; set; }
    }
}
