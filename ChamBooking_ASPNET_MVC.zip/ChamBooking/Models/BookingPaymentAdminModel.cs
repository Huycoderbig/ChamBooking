// ==========================================================================
// TỔNG QUAN FILE: Models/BookingPaymentAdminModel.cs
// - File này làm gì: Định nghĩa class khuôn mẫu dữ liệu cho Đơn đặt phòng (Booking)
//   và Lịch sử giao dịch thanh toán (Payments) trong giao diện Quản trị Admin.
// - Nằm ở đâu trong dự án: Thư mục Models/BookingPaymentAdminModel.cs.
// - Cách chạy / gọi đến file này: Được truyền từ AdminController xuống giao diện
//   Views/Admin/Dashboard.cshtml.
// ==========================================================================

namespace ChamBooking.Models
{
    // Class lưu thông tin Đơn đặt phòng & Giao dịch thanh toán cho trang Quản trị
    public class BookingPaymentAdminModel
    {
        // Mã đơn đặt phòng (VD: "CHAM-89412")
        public string BookingCode { get; set; }
        // Họ tên khách đặt phòng
        public string CustomerName { get; set; }
        // Số điện thoại liên hệ của khách
        public string Phone { get; set; }
        // Tên khách sạn và loại phòng khách đã đặt
        public string HotelAndRoom { get; set; }
        // Ngày nhận phòng và trả phòng
        public string CheckInOut { get; set; }
        // Tổng số tiền thanh toán (đã gồm thuế)
        public decimal TotalAmount { get; set; }
        // Phương thức thanh toán khách sử dụng (Visa, MoMo, Tiền mặt)
        public string PaymentMethod { get; set; }
        // Trạng thái giao dịch thanh toán ("Đã thanh toán" hoặc "Chờ thu tại quầy")
        public string PaymentStatus { get; set; }
    }
}
