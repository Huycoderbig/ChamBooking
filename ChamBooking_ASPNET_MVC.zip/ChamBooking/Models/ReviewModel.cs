// ==========================================================================
// TỔNG QUAN FILE: Models/ReviewModel.cs
// - File này làm gì: Định nghĩa class khuôn mẫu dữ liệu cho phần Đánh giá /
//   Bình luận của khách hàng (Reviews).
// - Nằm ở đâu trong dự án: Thư mục Models/ReviewModel.cs.
// - Cách chạy / gọi đến file này: Dùng ở Trang chủ (Index.cshtml), Trang Chi tiết
//   khách sạn (Details.cshtml) và Trang Quản trị (Dashboard.cshtml).
// ==========================================================================

namespace ChamBooking.Models
{
    // Class lưu thông tin một Đánh giá / Bình luận (Review) của khách hàng
    public class ReviewModel
    {
        // Mã bình luận
        public int Id { get; set; }
        // Họ và tên khách hàng đã nghỉ tại khách sạn
        public string CustomerName { get; set; }
        // Hai chữ cái viết tắt tên khách hàng để hiển thị vào vòng tròn Avatar
        public string AvatarInitials { get; set; }
        // Thông tin chuyến đi (VD: "Đi cặp đôi • Tháng 10/2026")
        public string TripInfo { get; set; }
        // Tên khách sạn mà khách hàng này đánh giá
        public string HotelName { get; set; }
        // Số sao khách chấm (từ 1 đến 5 sao)
        public int StarRating { get; set; }
        // Điểm số chi tiết (thang điểm 10, VD: 9.8)
        public string ScoreText { get; set; }
        // Ngày đăng tải bình luận
        public string CreatedDate { get; set; }
        // Nội dung nhận xét thực tế của khách hàng
        public string Comment { get; set; }
    }
}
