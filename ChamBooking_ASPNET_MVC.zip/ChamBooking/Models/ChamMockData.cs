// ==========================================================================
// TỔNG QUAN FILE: Models/ChamMockData.cs
// - File này làm gì: Đóng vai trò là kho dữ liệu giả (Mock Data) tập trung,
//   khởi tạo sẵn các danh sách (List) Điểm đến, Khách sạn, Loại phòng,
//   Đánh giá (Reviews), Phương thức thanh toán (Payments) và Lịch sử giao dịch.
//   Hoàn toàn KHÔNG dùng Entity Framework và KHÔNG kết nối SQL Server.
// - Nằm ở đâu trong dự án: Thư mục Models/ChamMockData.cs.
// - Cách chạy / gọi đến file này: Các Controller (Home, Search, Hotel, Booking,
//   Admin) sẽ gọi các hàm tĩnh trong class này để lấy dữ liệu truyền ra View.
// ==========================================================================

// Khai báo thư viện danh sách List<T>
using System.Collections.Generic;

namespace ChamBooking.Models
{
    // Class tĩnh chứa toàn bộ dữ liệu giả (Mock Data) của website "Chạm"
    public static class ChamMockData
    {
        // 1. Hàm trả về danh sách 4 Điểm đến nổi bật cho Trang chủ
        public static List<DestinationModel> GetDestinations()
        {
            return new List<DestinationModel>
            {
                new DestinationModel { Name = "Đà Lạt", Vibe = "Sương mù & Rừng thông", HotelCount = 428, ImageUrl = "https://images.unsplash.com/photo-1583417319070-4a69db38a482?auto=format&fit=crop&w=800&q=80" },
                new DestinationModel { Name = "Phú Quốc", Vibe = "Hoàng hôn & Biển ngọc", HotelCount = 315, ImageUrl = "https://images.unsplash.com/photo-1540202404-a2f29016b523?auto=format&fit=crop&w=800&q=80" },
                new DestinationModel { Name = "Hội An", Vibe = "Phố cổ & Đèn lồng", HotelCount = 290, ImageUrl = "https://images.unsplash.com/photo-1559592413-7cec4d0cae2b?auto=format&fit=crop&w=800&q=80" },
                new DestinationModel { Name = "Sa Pa", Vibe = "Mây núi & Bản làng", HotelCount = 194, ImageUrl = "https://images.unsplash.com/photo-1528127269322-539801943592?auto=format&fit=crop&w=800&q=80" }
            };
        }

        // 2. Hàm trả về danh sách các Khách sạn giả lập (Mock Data)
        public static List<HotelModel> GetHotels()
        {
            return new List<HotelModel>
            {
                new HotelModel
                {
                    Id = 101,
                    Name = "Chạm Mây Boutique Resort & Spa Đà Lạt",
                    City = "Đà Lạt",
                    Address = "Đồi Dã Chiến, Phường 11, TP. Đà Lạt, Lâm Đồng",
                    Stars = 5,
                    RatingScore = 9.4,
                    RatingLabel = "Tuyệt hảo",
                    ReviewCount = 342,
                    OldPrice = 2450000,
                    PricePerNight = 1680000,
                    PromoBadge = "Ưu đãi lữ khách -31%",
                    MainImage = "https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=1000&q=80",
                    GalleryImages = new List<string>
                    {
                        "https://images.unsplash.com/photo-1582719508461-905c673771fd?auto=format&fit=crop&w=800&q=80",
                        "https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=800&q=80",
                        "https://images.unsplash.com/photo-1571896349842-33c89424de2d?auto=format&fit=crop&w=800&q=80",
                        "https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&w=800&q=80"
                    },
                    Amenities = new List<string> { "Hồ bơi nước ấm", "Bữa sáng miễn phí", "Ban công săn mây", "Spa thảo mộc", "Wi-Fi tốc độ cao", "Đưa đón sân bay" },
                    Description = "Ẩn mình giữa triền đồi thông yên tĩnh hướng thẳng ra thung lũng mây Trại Mát, Chạm Mây Boutique Resort mang kiến trúc gỗ thông ấm cúng. Mỗi sáng thức dậy, bạn chỉ cần kéo rèm là chạm ngay vào biển sương lành lạnh."
                },
                new HotelModel
                {
                    Id = 102,
                    Name = "An Nhiên Heritage Villa & Pool Hội An",
                    City = "Hội An",
                    Address = "142 Nguyễn Duy Hiệu, Cẩm Châu, TP. Hội An, Quảng Nam",
                    Stars = 4,
                    RatingScore = 9.2,
                    RatingLabel = "Tuyệt vời",
                    ReviewCount = 218,
                    OldPrice = 1550000,
                    PricePerNight = 1120000,
                    PromoBadge = "Tặng trà chiều phố cổ",
                    MainImage = "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=1000&q=80",
                    GalleryImages = new List<string>
                    {
                        "https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=800&q=80",
                        "https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=800&q=80",
                        "https://images.unsplash.com/photo-1571896349842-33c89424de2d?auto=format&fit=crop&w=800&q=80",
                        "https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&w=800&q=80"
                    },
                    Amenities = new List<string> { "Xe đạp miễn phí", "Hồ bơi muối khoáng", "Bữa sáng miễn phí", "Cách phố cổ 600m", "Wi-Fi tốc độ cao" },
                    Description = "Chỉ cách phố cổ Hội An vài phút đạp xe thong dong dưới giàn hoa giấy, An Nhiên Heritage Villa mang sắc vàng nghệ truyền thống và hồ bơi xanh mát."
                },
                new HotelModel
                {
                    Id = 103,
                    Name = "Solis Oceanfront Resort & Villa Phú Quốc",
                    City = "Phú Quốc",
                    Address = "Bãi Ông Lang, Cửa Dương, TP. Phú Quốc, Kiên Giang",
                    Stars = 5,
                    RatingScore = 9.5,
                    RatingLabel = "Tuyệt hảo",
                    ReviewCount = 419,
                    OldPrice = 3200000,
                    PricePerNight = 2350000,
                    PromoBadge = "Bãi biển riêng tư",
                    MainImage = "https://images.unsplash.com/photo-1571896349842-33c89424de2d?auto=format&fit=crop&w=1000&q=80",
                    GalleryImages = new List<string>
                    {
                        "https://images.unsplash.com/photo-1582719508461-905c673771fd?auto=format&fit=crop&w=800&q=80",
                        "https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=800&q=80",
                        "https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=800&q=80",
                        "https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&w=800&q=80"
                    },
                    Amenities = new List<string> { "Sát biển Ông Lang", "Hồ bơi vô cực", "Bữa sáng miễn phí", "Đưa đón sân bay", "Bar hoàng hôn" },
                    Description = "Nơi lý tưởng để ngắm trọn vẹn khoảnh khắc mặt trời đỏ rực chìm xuống mặt biển Phú Quốc, bước chân ra khỏi hiên phòng là chạm vào cát mịn."
                },
                new HotelModel
                {
                    Id = 104,
                    Name = "Mường Hoa Valley Eco Lodge Sa Pa",
                    City = "Sa Pa",
                    Address = "Thôn Lao Chải, Xã Hoàng Liên, Thị xã Sa Pa, Lào Cai",
                    Stars = 4,
                    RatingScore = 9.1,
                    RatingLabel = "Tuyệt vời",
                    ReviewCount = 176,
                    OldPrice = 1350000,
                    PricePerNight = 950000,
                    PromoBadge = "View ruộng bậc thang",
                    MainImage = "https://images.unsplash.com/photo-1596394516093-501ba68a0ba6?auto=format&fit=crop&w=1000&q=80",
                    GalleryImages = new List<string>
                    {
                        "https://images.unsplash.com/photo-1582719508461-905c673771fd?auto=format&fit=crop&w=800&q=80",
                        "https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=800&q=80",
                        "https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=800&q=80",
                        "https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&w=800&q=80"
                    },
                    Amenities = new List<string> { "Ban công săn mây", "Tắm lá thuốc Dao đỏ", "Bữa sáng miễn phí", "Lò sưởi trong phòng" },
                    Description = "Những căn bungalow bằng đá cuội và gỗ thông thơm dịu nằm bên thung lũng Mường Hoa, phóng tầm mắt ngắm trọn ruộng bậc thang."
                }
            };
        }

        // 3. Hàm trả về danh sách các Loại phòng (Room Types)
        public static List<RoomTypeModel> GetRoomTypes()
        {
            return new List<RoomTypeModel>
            {
                new RoomTypeModel
                {
                    RoomCode = "RM-01",
                    RoomName = "Deluxe Pine View Balcony (Ban công hướng rừng thông)",
                    AreaSize = "36 m²",
                    BedInfo = "1 Giường đôi lớn (King size)",
                    Capacity = "2 Người lớn, 1 Trẻ em",
                    Price = 1680000,
                    RoomImage = "https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=600&q=80",
                    Benefits = new List<string> { "Bao gồm buffet sáng 2 khách", "Miễn phí hủy phòng trước 48h", "Tặng trà hoa cúc & cà phê phin" }
                },
                new RoomTypeModel
                {
                    RoomCode = "RM-02",
                    RoomName = "Premier Cloud Hunting Suite (Bồn tắm ngâm ngắm mây)",
                    AreaSize = "48 m²",
                    BedInfo = "1 Giường Super King 2m x 2m2",
                    Capacity = "2 Người lớn, 2 Trẻ em",
                    Price = 2290000,
                    RoomImage = "https://images.unsplash.com/photo-1582719508461-905c673771fd?auto=format&fit=crop&w=600&q=80",
                    Benefits = new List<string> { "Bao gồm buffet sáng + Trà chiều", "Bồn tắm sứ cạnh khung kính lớn", "Xác nhận phòng tức thì" }
                },
                new RoomTypeModel
                {
                    RoomCode = "RM-03",
                    RoomName = "Family Attic Wooden Villa (Biệt thự gác mái gia đình)",
                    AreaSize = "75 m²",
                    BedInfo = "2 Giường đôi lớn + Sofa bed",
                    Capacity = "4 Người lớn, 2 Trẻ em",
                    Price = 3450000,
                    RoomImage = "https://images.unsplash.com/photo-1566665797739-1674de7a421a?auto=format&fit=crop&w=600&q=80",
                    Benefits = new List<string> { "Bao gồm bữa sáng cho 4 khách", "Sân nướng BBQ riêng ngoài hiên", "Đưa đón sân bay miễn phí" }
                }
            };
        }

        // 4. Hàm trả về danh sách các Đánh giá của khách hàng (Reviews)
        public static List<ReviewModel> GetReviews()
        {
            return new List<ReviewModel>
            {
                new ReviewModel
                {
                    Id = 1,
                    CustomerName = "Nguyễn Minh Khuê",
                    AvatarInitials = "MK",
                    TripInfo = "Đi cặp đôi • Tháng 10/2026",
                    HotelName = "Chạm Mây Boutique Resort & Spa Đà Lạt",
                    StarRating = 5,
                    ScoreText = "9.8",
                    CreatedDate = "28/10/2026",
                    Comment = "Mình đã đi Đà Lạt hơn chục lần nhưng cảm giác sáng sớm mở cửa ban công ở Chạm Mây vẫn làm mình nổi da gà vì quá đẹp. Phòng thơm mùi tinh dầu sả chanh tự nhiên, lễ tân cực kỳ chu đáo."
                },
                new ReviewModel
                {
                    Id = 2,
                    CustomerName = "Trần Hoàng Nam",
                    AvatarInitials = "HN",
                    TripInfo = "Gia đình nhỏ • Tháng 10/2026",
                    HotelName = "Solis Oceanfront Resort & Villa Phú Quốc",
                    StarRating = 5,
                    ScoreText = "9.5",
                    CreatedDate = "19/10/2026",
                    Comment = "Đặt qua website Chạm cực kỳ nhanh gọn, giá tốt hơn đặt trực tiếp tại quầy. Bữa sáng đa dạng, hồ bơi nước ấm nên hai bé nhà mình thích mê."
                },
                new ReviewModel
                {
                    Id = 3,
                    CustomerName = "Lê Thảo Vy",
                    AvatarInitials = "TV",
                    TripInfo = "Đi một mình • Tháng 09/2026",
                    HotelName = "An Nhiên Heritage Villa & Pool Hội An",
                    StarRating = 4,
                    ScoreText = "9.0",
                    CreatedDate = "05/10/2026",
                    Comment = "Không gian yên tĩnh đúng chất nghỉ dưỡng chữa lành. Chăn ga gối đệm êm, cách âm tốt, mượn xe đạp dạo phố cổ buổi chiều rất chill."
                }
            };
        }

        // 5. Hàm trả về danh sách các Phương thức thanh toán (Payments)
        public static List<PaymentMethodModel> GetPaymentMethods()
        {
            return new List<PaymentMethodModel>
            {
                new PaymentMethodModel
                {
                    Code = "MOMO",
                    Title = "Ví điện tử MoMo / Quét mã QR Ngân hàng",
                    Subtitle = "Xác nhận giữ phòng tức thì trong 5 giây, miễn phí giao dịch",
                    Badge = "Khuyên dùng",
                    IconClass = "bi-qr-code-scan",
                    SimulatedStatus = "Trạng thái giả lập: Đang chờ quét mã QR MoMo (Tự động xuất biên lai ngay sau khi quét)"
                },
                new PaymentMethodModel
                {
                    Code = "VISA",
                    Title = "Thẻ Quốc tế (Visa / MasterCard / JCB)",
                    Subtitle = "Bảo mật chuẩn 3D-Secure, không thu phí cà thẻ",
                    Badge = "Bảo mật cao",
                    IconClass = "bi-credit-card-2-front",
                    SimulatedStatus = "Trạng thái giả lập: Cổng thanh toán thẻ Quốc tế 3D-Secure đã sẵn sàng kết nối"
                },
                new PaymentMethodModel
                {
                    Code = "CASH",
                    Title = "Tiền mặt (Thanh toán trực tiếp tại lễ tân khách sạn)",
                    Subtitle = "Đặt giữ phòng trước, chỉ thanh toán khi đến nhận phòng (Check-in)",
                    Badge = "Linh hoạt",
                    IconClass = "bi-cash-coin",
                    SimulatedStatus = "Trạng thái giả lập: Đơn đặt phòng được bảo lưu — Thanh toán tại quầy lễ tân khi nhận phòng"
                }
            };
        }

        // 6. Hàm trả về danh sách Đơn đặt phòng & Lịch sử giao dịch cho trang Quản trị (Admin UI)
        public static List<BookingPaymentAdminModel> GetAdminTransactions()
        {
            return new List<BookingPaymentAdminModel>
            {
                new BookingPaymentAdminModel
                {
                    BookingCode = "CHAM-89412",
                    CustomerName = "Nguyễn Minh Khuê",
                    Phone = "0908 412 889",
                    HotelAndRoom = "Chạm Mây Resort Đà Lạt • Premier Suite (x1)",
                    CheckInOut = "14/11/2026 - 16/11/2026",
                    TotalAmount = 5038000,
                    PaymentMethod = "Ví MoMo QR",
                    PaymentStatus = "Đã thanh toán"
                },
                new BookingPaymentAdminModel
                {
                    BookingCode = "CHAM-89415",
                    CustomerName = "Phạm Quốc Bảo",
                    Phone = "0983 115 204",
                    HotelAndRoom = "Solis Resort Phú Quốc • Deluxe View (x2)",
                    CheckInOut = "20/11/2026 - 22/11/2026",
                    TotalAmount = 7392000,
                    PaymentMethod = "Thẻ Visa (*4829)",
                    PaymentStatus = "Đã thanh toán"
                },
                new BookingPaymentAdminModel
                {
                    BookingCode = "CHAM-89419",
                    CustomerName = "Đặng Thu Hà",
                    Phone = "0912 667 340",
                    HotelAndRoom = "An Nhiên Villa Hội An • Deluxe View (x1)",
                    CheckInOut = "18/11/2026 - 19/11/2026",
                    TotalAmount = 1232000,
                    PaymentMethod = "Tiền mặt tại quầy",
                    PaymentStatus = "Chờ thu tại quầy"
                }
            };
        }
    }
}
